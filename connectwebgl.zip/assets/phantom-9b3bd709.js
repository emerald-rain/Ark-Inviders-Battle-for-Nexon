const e=`
<svg width="100%" height="100%" viewBox="0 0 128 128" fill="none" xmlns="http://www.w3.org/2000/svg">
<g clip-path="url(#clip0_8241_140154)">
<circle cx="64" cy="64" r="64" fill="url(#paint0_linear_8241_140154)"/>
<g filter="url(#filter0_d_8241_140154)">
<path d="M110.584 64.9142H99.1423C99.1423 41.7651 80.1733 23 56.7726 23C33.6615 23 14.8719 41.3057 14.412 64.0583C13.9363 87.577 36.2412 108 60.0189 108H63.0097C83.9725 108 112.069 91.7667 116.459 71.9874C117.27 68.3413 114.359 64.9142 110.584 64.9142ZM39.7691 65.9454C39.7691 69.0411 37.2098 71.5729 34.0804 71.5729C30.9511 71.5729 28.3918 69.0399 28.3918 65.9454V56.8414C28.3918 53.7457 30.9511 51.2139 34.0804 51.2139C37.2098 51.2139 39.7691 53.7457 39.7691 56.8414V65.9454ZM59.5227 65.9454C59.5227 69.0411 56.9634 71.5729 53.834 71.5729C50.7047 71.5729 48.1454 69.0399 48.1454 65.9454V56.8414C48.1454 53.7457 50.7058 51.2139 53.834 51.2139C56.9634 51.2139 59.5227 53.7457 59.5227 56.8414V65.9454Z" fill="url(#paint1_linear_8241_140154)"/>
</g>
</g>
<defs>
<filter id="filter0_d_8241_140154" x="6.76409" y="15.3596" width="117.472" height="100.281" filterUnits="userSpaceOnUse" color-interpolation-filters="sRGB">
<feFlood flood-opacity="0" result="BackgroundImageFix"/>
<feColorMatrix in="SourceAlpha" type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 127 0" result="hardAlpha"/>
<feOffset/>
<feGaussianBlur stdDeviation="3.82022"/>
<feColorMatrix type="matrix" values="0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0 0.3 0"/>
<feBlend mode="normal" in2="BackgroundImageFix" result="effect1_dropShadow_8241_140154"/>
<feBlend mode="normal" in="SourceGraphic" in2="effect1_dropShadow_8241_140154" result="shape"/>
</filter>
<linearGradient id="paint0_linear_8241_140154" x1="64" y1="0" x2="64" y2="128" gradientUnits="userSpaceOnUse">
<stop stop-color="#534BB1"/>
<stop offset="1" stop-color="#551BF9"/>
</linearGradient>
<linearGradient id="paint1_linear_8241_140154" x1="65.5001" y1="23" x2="65.5001" y2="108" gradientUnits="userSpaceOnUse">
<stop stop-color="white"/>
<stop offset="1" stop-color="white" stop-opacity="0.82"/>
</linearGradient>
<clipPath id="clip0_8241_140154">
<rect width="128" height="128" fill="white"/>
</clipPath>
</defs>
</svg>
`;export{e as default};
